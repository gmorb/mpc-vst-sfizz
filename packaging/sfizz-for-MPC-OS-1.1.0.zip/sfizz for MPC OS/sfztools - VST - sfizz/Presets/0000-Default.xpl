<?xml version="1.0" encoding="UTF-8"?>

<pluginstate>
  <version file="1" date="2026-10-17-22-22"/>
  <PLUGIN name="sfizz" descriptiveName="sfizz" format="VST" category="Synth" manufacturer="sfztools"
          version="1.0" file="%payload-path%/sfztools - VST - sfizz/sfizz_mpc.so" uid="53667a4d" isInstrument="1" fileTime="0"
          infoUpdateTime="0" numInputs="0" numOutputs="2" isShell="0"/>
  <preset>Default</preset>
  <state>161.CMlaKA....fQBMDZ....ALkY50D..P.S....A...............................................................................................................................................................................A..</state>
</pluginstate>
